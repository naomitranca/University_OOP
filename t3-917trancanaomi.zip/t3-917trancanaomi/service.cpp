//
// Created by Naomi on 5/24/2022.
//

#include "service.h"
#include <fstream>
using namespace std;

#define FILE_DELIMITER " | "

service::service(repo_shoppingList& repository) : repository(repository)
{
    // nothing yet
}

service::~service()
{
    // nothing yet
}

void service::add(std::string category, std::string name, int quantity)
{
    shoppingList list(category, name, quantity);
    repository.repo_add(list);
}

void service::remove(std::string name)
{
    shoppingList list = repository.repo_search(name);
    repository.repo_remove(list);
}

void service::update(std::string category, std::string new_name, int new_quantity)
{
    shoppingList old_list = repository.repo_search(category);
    shoppingList new_list = shoppingList(category, new_name, new_quantity);
    repository.repo_update(old_list, new_list);
}

vector<shoppingList> service::List()
{
    return repository.repo_list();
}

void service::ReadFile(string PathToFile)
{
    ifstream File(PathToFile);
    string Line;
    while (getline(File, Line))
    {
        auto SplitList = service::SplitString(Line, FILE_DELIMITER);
        const int category_index = 0, name_index = 1, quantity_index = 2;
        std::string category = SplitList[category_index];
        std::string name = SplitList[name_index];
        int quantity = stoi(SplitList[quantity_index]);
        this->add(category, name, quantity);
    }
}

int service::nr_of_lists(std::string name)
{
    int count = 0;
    auto Data = List();
    for (auto list : Data)
    {
        if (list.get_name() == name)
            count++;
    }
    return count;
}

vector<string> service::SplitString(string SomeString, string Delimiter)
{
    size_t StartPosition = 0, StopPosition;
    vector<string> Pieces;
    while ((StopPosition = SomeString.find(Delimiter, StartPosition + 1)) != string::npos)
    {
        Pieces.push_back(SomeString.substr(StartPosition, StopPosition - StartPosition));
        StartPosition = StopPosition + Delimiter.size();
    }
    if (StartPosition < SomeString.size())
        Pieces.push_back(SomeString.substr(StartPosition));
    return Pieces;
}
