//
// Created by Naomi on 5/24/2022.
//

#ifndef T3_917TRANCANAOMI_OOPTEST3_H
#define T3_917TRANCANAOMI_OOPTEST3_H
#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_OOPTest3.h"
#include "service.h"


class OOPTest3 : public QMainWindow
{
    Q_OBJECT

public:
    OOPTest3(QWidget *parent = Q_NULLPTR);
private:
    service Controller;
    Ui::OOPTest3Class ui;
    void update_buttons();
    static std::string list_to_string(shoppingList);
    void Tests();
};
#endif //T3_917TRANCANAOMI_OOPTEST3_H
