//
// Created by Naomi on 5/24/2022.
//

#ifndef T3_917TRANCANAOMI_SERVICE_H
#define T3_917TRANCANAOMI_SERVICE_H
#pragma once
#include "repository.h"
#include "shoppingList.h"
#include "AppException.h"
#include <vector>
#include <string>

class service
{
private:
    repo_shoppingList& repository;
    static std::vector<std::string> SplitString(std::string, std::string);
public:
    service(repo_shoppingList& = repo_shoppingList());
    ~service();
    void add(std::string, std::string, int);
    void remove(std::string);
    void update(std::string, std::string, int);
    std::vector<shoppingList> List();
    void ReadFile(std::string);
    int nr_of_lists(std::string);
};

#endif //T3_917TRANCANAOMI_SERVICE_H
