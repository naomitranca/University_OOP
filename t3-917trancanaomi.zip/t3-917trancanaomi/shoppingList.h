//
// Created by Naomi on 5/24/2022.
//

#ifndef T3_917TRANCANAOMI_SHOPPINGLIST_H
#define T3_917TRANCANAOMI_SHOPPINGLIST_H
#pragma once
#include <string>
class shoppingList
{
private:
    std::string category;
    std::string name;
    int quantity;
public:
    shoppingList(std::string, std::string, int);
    ~shoppingList();
    std::string get_category() const;
    std::string get_name() const;
    int get_quantity() const;
    bool operator==(shoppingList) const;
    void set_category(std::string);
    void set_name(std::string);
    void set_quantity(int);

};
#endif //T3_917TRANCANAOMI_SHOPPINGLIST_H
