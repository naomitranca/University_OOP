//
// Created by Naomi on 5/24/2022.
//

#ifndef T3_917TRANCANAOMI_REPOSITORY_H
#define T3_917TRANCANAOMI_REPOSITORY_H
#pragma once
#include "shoppingList.h"
#include <vector>
#define NULL_shoppingList shoppingList("","",0)

class repo_shoppingList
{
private:
    std::vector<shoppingList> shoppingLists;
public:
    void repo_add(shoppingList);
    void repo_remove(shoppingList);
    void repo_update(shoppingList, shoppingList);
    shoppingList repo_search(std::string);
    std::vector<shoppingList> repo_list();
};
#endif //T3_917TRANCANAOMI_REPOSITORY_H
