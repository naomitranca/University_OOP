//
// Created by Naomi on 5/24/2022.
//

#include "OOPTest3.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    OOPTest3 w;
    w.show();
    return a.exec();
}


