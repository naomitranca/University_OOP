//
// Created by Naomi on 5/24/2022.
//

#include "repository.h"
#include <algorithm>
#include "appException.h"
using namespace std;
void repo_shoppingList::repo_add(shoppingList list)
{
    if ( ! (repo_search(list.get_category()) == NULL_shoppingList))
        throw appException("There already exists an element with that manufacture");
    shoppingLists.push_back(list);
}

void repo_shoppingList::repo_remove(shoppingList list)
{
    auto NewEnd = remove(shoppingLists.begin(), shoppingLists.end(),list);
    if (NewEnd == shoppingLists.end())
        throw appException("The element doesn't exist!");
    shoppingLists.erase(NewEnd, shoppingLists.end());
}

void repo_shoppingList::repo_update(shoppingList old_list, shoppingList new_list)
{
    if (repo_search(old_list.get_category()) == NULL_shoppingList)
        throw appException("The element doesn't exist!");
    replace(shoppingLists.begin(), shoppingLists.end(), old_list, new_list);
}

vector<shoppingList> repo_shoppingList::repo_list()
{
    return shoppingLists;
}

shoppingList repo_shoppingList::repo_search(std::string name)
{
    for (auto list : shoppingLists)
        if (list.get_name() == name)
            return list;
    return NULL_shoppingList;
}
