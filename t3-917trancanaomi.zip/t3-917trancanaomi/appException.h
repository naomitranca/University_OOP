//
// Created by Naomi on 5/24/2022.
//

#ifndef T3_917TRANCANAOMI_APPEXCEPTION_H
#define T3_917TRANCANAOMI_APPEXCEPTION_H
#pragma once
#include <exception>
class appException : public std::exception
{
    using exception::exception;
};
#endif //T3_917TRANCANAOMI_APPEXCEPTION_H
