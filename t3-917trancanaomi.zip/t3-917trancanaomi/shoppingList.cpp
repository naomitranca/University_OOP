//
// Created by Naomi on 5/24/2022.
//

#include "shoppingList.h"
shoppingList::shoppingList(std::string, std::string, int)
{
    // still nothing
}

shoppingList::~shoppingList()
{
    // nothing for now
}

std::string shoppingList::get_category() const
{
    return category;
}

std::string shoppingList::get_name() const
{
    return name;
}

int shoppingList::get_quantity() const
{
    return quantity;
}
bool shoppingList::operator==(shoppingList AnotherElement) const
{
    if (this->get_category() == AnotherElement.get_category() &&
        this->get_name() == AnotherElement.get_name()&&
        this->get_quantity() == AnotherElement.get_quantity() )
        return true;
    return false;
}

void shoppingList::set_category(std::string new_category)
{
    category = new_category;
}

void shoppingList::set_name(std::string new_name)
{
    name = new_name;
}


void shoppingList::set_quantity(int new_quantity)
{
    quantity = new_quantity;
}
