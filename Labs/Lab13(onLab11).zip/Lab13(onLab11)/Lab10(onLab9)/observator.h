#pragma once
class Observator// :))
{
public:
    virtual void update() = 0;
    virtual ~Observator() = 0 {};
};


